function isValidDomain(domain) {
    const domainRegex = /^((\*\.)?[a-z0-9]+(-[a-z0-9]+)*\.)+[a-z]{2,}$/i;
    return domainRegex.test(domain);
}

function isValidUrl(url) {
    const urlRegex = /^https?:\/\/([a-z0-9]+(-[a-z0-9]+)*\.)+[a-z]{2,}([\/\?].*)?$/i;
    return urlRegex.test(url);
}

function showModal(message) {
    const modal = new bootstrap.Modal(document.getElementById('myModal'), {});
    document.querySelector('#myModal .modal-body').textContent = message;
    modal.show();
}

function showError(inputId, message) {
    const inputElement = document.getElementById(inputId);
    const feedbackElement = document.getElementById(inputId + '-feedback');
    inputElement.classList.add('is-invalid');
    feedbackElement.textContent = message;
}

function resetForm() {
    document.getElementById('domain').value = '';
    document.getElementById('redirect').value = '';
    document.getElementById('domain').classList.remove('is-invalid');
    document.getElementById('redirect').classList.remove('is-invalid');
}

function validateForm() {
    const domainInput = document.getElementById('domain');
    const domainValue = domainInput.value.trim();
    const redirectInput = document.getElementById('redirect');
    const redirectValue = redirectInput.value.trim();

    let isValid = true;

    if (!isValidDomain(domainValue)) {
        showError('domain', '请输入正确的域名');
        isValid = false;
    } else if (isDomainDuplicate(domainValue)) {
        showError('domain', '域名已存在，请勿重复添加');
        isValid = false;
    }

    // if (!isValidUrl(redirectValue)) {
    //     showError('redirect', '请输入正确的跳转地址');
    //     isValid = false;
    // }

    if (isValid) {
        addRecord(domainValue, redirectValue);
    } else {
        showModal("请输入正确的域名或跳转地址");
    }

    return false;
}

function addRecord(domain, redirect) {
    const groupSelect = document.getElementById('group');
    const selectedGroup = groupSelect.options[groupSelect.selectedIndex].value; // 获取选中的分组值


    fetch('/add', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: `domain=${encodeURIComponent(domain)}&redirect=${encodeURIComponent(redirect)}&group=${encodeURIComponent(selectedGroup)}` // 添加选中的分组值
    })
    .then(response => {
        if (response.ok) {
            location.reload();
        } else {
        // 如果返回了错误，读取错误消息
        return response.json().then(data => {
            throw new Error(data.error);
        });
        }
    })
    .catch(error => {
        // 显示从服务器获取的错误消息，而不是固定的消息
        showModal(error.message);
    });
}

function isDomainDuplicate(domain) {
    const domainCells = document.querySelectorAll('tbody tr td:first-child');
    for (const cell of domainCells) {
        if (cell.textContent === domain) {
        return true;
    }
}
return false;
}

function resetBulkAddForm() {
    document.getElementById("bulk-records").value = "";
}

function submitBulkAddForm(event) {
    event.preventDefault();

    const bulkAddForm = document.getElementById("bulk-add-form");
    const groupSelect = document.getElementById('group');
    const selectedGroup = groupSelect.options[groupSelect.selectedIndex].value; // 获取选中的分组值
    const bulkRecords = document.getElementById("bulk-records");

    // 检查批量添加的文本框内容
    if (bulkRecords.value.trim() === '') {
        showModal("请输入域名或跳转地址");
        return;
    }


    let formData = new FormData(bulkAddForm);
    let encodedFormBody = new URLSearchParams(formData).toString() + `&group=${encodeURIComponent(selectedGroup)}`; // 添加选中的分组值



    fetch(`/bulk_add/${encodeURIComponent(selectedGroup)}`, {
        method: "POST",
        body: encodedFormBody,
        headers: {
            "X-Requested-With": "XMLHttpRequest",
            'Content-Type': 'application/x-www-form-urlencoded'
        }
    })
        .then((response) => {
            if (response.ok) {
                location.reload();
            } else {
                return response.json();
            }
        })
        .then((data) => {
            if (data && data.error) {
                const errorModalBody = document.getElementById("errorModalBody");
                errorModalBody.textContent = data.error;
                const errorModal = new bootstrap.Modal(document.getElementById("errorModal"));
                errorModal.show();
            }
        })
        .catch((error) => {
            console.error("Error:", error);
        });
}


document.querySelector('form').addEventListener('submit', (event) => {
    event.preventDefault();
    validateForm();
    });

//修改start
//定义全局变量来存储单元格
let currentDomainCell;
let currentRedirectCell;
let currentGroupCell;

document.querySelectorAll('.edit-btn').forEach(btn => {
    btn.addEventListener('click', (event) => {
        const row = event.target.closest('tr');
        currentDomainCell = row.cells[1];  // changed from '.domain-cell' to cells[1]
        currentRedirectCell = row.cells[2]; // changed from '.redirect-cell' to cells[2]
        currentGroupCell = row.cells[3]; // changed from '.group-cell' to cells[3]

        const originalDomain = currentDomainCell.textContent;
        const originalRedirect = currentRedirectCell.textContent;
        const originalGroup = currentGroupCell.textContent;

        const editModal = document.getElementById('editModal');

        document.getElementById('newDomain').value = originalDomain; // set original domain
        document.getElementById('newRedirect').value = originalRedirect;
        
        // Get groups from backend and fill in the group dropdown
        $.ajax({
            url: "/groups",
            type: "GET",
            success: function(response) {
                let newGroupSelect = $("#newGroup");
                newGroupSelect.empty();
                Object.keys(response.data).forEach(function(groupName) {
                    let selectedAttr = (groupName === originalGroup) ? "selected" : "";
                    newGroupSelect.append(`<option value="${groupName}" ${selectedAttr}>${groupName} (${response.data[groupName].records.length} records)</option>`);
                });
            },
            error: function(error) {
                console.error("Error retrieving groups", error);
            }
        });

        new bootstrap.Modal(editModal).show();
    });
});

function setupConfirmEditButton() {
    document.querySelector("#confirmEditBtn").addEventListener("click", function() {
        let newDomain = document.querySelector("#newDomain").value;
        let newRedirect = document.querySelector("#newRedirect").value;
        let newGroup = document.querySelector("#newGroup").value;
        let errorMsg = document.querySelector("#editError");

        errorMsg.textContent = ''; // Clear any previous error messages

        if (!isValidDomain(newDomain)) {
            errorMsg.textContent = "域名格式错误";
            return false;
        }

        // if(!isValidUrl(newRedirect)){
        //     errorMsg.textContent = "跳转地址格式错误";
        //     return false;
        // }

        fetch('/update/' + currentDomainCell.textContent, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                'old_domain': currentDomainCell.textContent,
                'new_domain': newDomain,
                'new_redirect': newRedirect,
                'new_group': newGroup
            })
        })
        .then(response => {
            if (!response.ok) {
                return response.json().then(err => {throw err;});
            }
            return response.json();
        })
        .then(data => {
            if (data.status == 'ok') {
                currentDomainCell.textContent = newDomain;
                currentRedirectCell.textContent = newRedirect;
                currentGroupCell.textContent = newGroup;
                // Close the modal after successful update
                $('#editModal').modal('hide');
            } 
        })
        .catch(err => {
            errorMsg.textContent = err.error;
        });
    });
}

function fetchTotalAccess() {
    fetch('/total_access')
        .then(response => {
            if (!response.ok) {
                throw new Error("HTTP error " + response.status);
            }
            return response.json();
        })
        .then(data => {
            document.getElementById('visit-count').innerHTML = data.total_access;
        })
        .catch(function() {
            this.dataError = true;
        })
}

window.onload = function() {
    setupConfirmEditButton();
    fetchTotalAccess();
};



var httpsButtons = document.getElementsByClassName('https-btn');
for (var i = 0; i < httpsButtons.length; i++) {
    httpsButtons[i].addEventListener('click', function() {
        var domain = this.getAttribute('data-domain');
        var loadingText = this.getAttribute('data-loading-text');

        this.innerHTML = '<i class="fa fa-spinner fa-spin"></i> ' + loadingText; // Use a loading spinner
        this.disabled = true; // Disable the button

        fetch('/enable_https/' + domain, {
            method: 'POST'
        })
        .then(response => response.json())
        .then(data => {
            // Regardless of the result, keep the button as "正在开启..."
        })
        .catch((error) => {
            // Regardless of the result, keep the button as "正在开启..."
        });
    });
}

function deleteRecord(domain) {
    fetch(`/delete/${domain}`, {
        method: 'POST'
    })
    .then(response => {
        if (response.ok) {
            location.reload();
        } else {
            // 如果返回了错误，读取错误消息
            return response.json().then(data => {
                throw new Error(data.error);
            });
            }
        })
        .catch(error => {
            // 显示从服务器获取的错误消息，而不是固定的消息
            showModal(error.message);
        });
}

document.querySelectorAll('.delete-btn').forEach(btn => {
    btn.addEventListener('click', (event) => {
        const domain = btn.getAttribute('data-domain'); // 修改这里
        const deleteModal = new bootstrap.Modal(document.getElementById('deleteConfirmModal'));

        // save the domain to the modal
        document.getElementById('deleteConfirmModal').dataset.domain = domain;

        deleteModal.show();
    });
});

// handle confirm delete
document.getElementById('confirmDelete').addEventListener('click', () => {
    const domain = document.getElementById('deleteConfirmModal').dataset.domain;
    deleteRecord(domain);
    new bootstrap.Modal(document.getElementById('deleteConfirmModal')).hide();
});

// Close modal when "取消" button is clicked
document.querySelector('#deleteConfirmModal .btn-secondary').addEventListener('click', () => {
    bootstrap.Modal.getInstance(document.getElementById('deleteConfirmModal')).hide();
});

//批量删除
let selectedDomains = [];

$('#bulk-delete').click(function() {
    selectedDomains = [];
    $('.select-item:checked').each(function() {
        selectedDomains.push($(this).data('domain'));
    });

    if (selectedDomains.length === 0) {
        showModal('请至少选择一个域名进行操作');
        return;
    }

    $('#bulkDeleteConfirmModal').modal('show');
});

$('#confirmBulkDelete').click(function() {
    // 隐藏模态框并显示加载指示器
    $('#bulkDeleteConfirmModal').modal('hide');
    $('#loadingIndicator').show();

    fetch('/bulk_delete', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({domains: selectedDomains}),
    })
    .then((response) => {
        if (!response.ok) throw new Error(response.statusText);
        return response.json();
    })
    .then((data) => {
        location.reload(true); // 强制从服务器加载页面
    })
    .catch((error) => {
        $('#bulkDeleteError').text(error).show();
        // 如果发生错误，隐藏加载指示器
        $('#loadingIndicator').hide();
    });
});

$('#bulkDeleteConfirmModal').on('hidden.bs.modal', function (e) {
  $('#bulkDeleteError').hide();
});

$(document).ready(function() {
    // 监听全选框状态
    $('#select-all').change(function() {
        var isChecked = $(this).prop('checked');  // 获取全选框当前状态

        // 设置所有其他复选框的状态与全选框一致
        $('.select-item').each(function() {
            $(this).prop('checked', isChecked);
        });
    });

    // 如果所有的复选框都被选中，则全选框也被选中，否则全选框取消选中
    $('.select-item').change(function() {
        var allChecked = $('.select-item:checked').length === $('.select-item').length;
        $('#select-all').prop('checked', allChecked);
    });
});


//批量修改
//点击批量修改按钮时
$('#bulk-edit').click(function() {
    selectedDomains = [];
    $('.select-item:checked').each(function() {
        selectedDomains.push($(this).data('domain'));
    });

    if (selectedDomains.length === 0) {
        showModal('请至少选择一个域名进行操作');
        return;
    }

    $('#bulkEditModal').modal('show');
});

//点击确认修改按钮时
$('#confirmBulkEdit').click(function() {
    let newRedirect = $('#newBulkRedirect').val();

    if(!newRedirect){
        $('#newBulkRedirect').addClass('is-invalid');
        $('#bulk-edit-feedback').text('跳转地址不能为空');
        return;
    }

    // if (!isValidUrl(newRedirect)) {
    //     $('#newBulkRedirect').addClass('is-invalid');
    //     $('#bulk-edit-feedback').text('跳转地址格式错误');
    //     return;
    // }

    $('#newBulkRedirect').removeClass('is-invalid');
    
    $('#bulkEditModal').modal('hide');
    $('#loadingIndicator').show();

    fetch('/bulk_edit', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({domains: selectedDomains, redirect: newRedirect}),
    })
    .then((response) => {
        if (!response.ok) throw new Error(response.statusText);
        return response.text();
    })
    .then(() => {
        location.reload(true); // 强制从服务器加载页面
    })
    .catch((error) => {
        // handle any errors
        console.error('Error:', error);
        $('#loadingIndicator').hide();
        alert('操作失败，请稍后重试');
    });
});

$('#editModal').on('hidden.bs.modal', function (e) {
  $('#bulkEditError').hide();
  $('#redirect-feedback').hide();
  $('#newRedirect').val('');
});


$(document).ready(function () {
    // 为表格的每一行（除表头）添加点击事件
    $("table").on("click", "tr:gt(0)", function (event) {
        // 如果点击的是复选框本身，不做任何操作
        if(event.target.type !== "checkbox") {
            // 找到该行第一个单元格内的复选框并改变其选中状态
            var checkbox = $(this).find("input[type='checkbox']");
            checkbox.prop("checked", !checkbox.prop("checked"));

            // 添加可视反馈：如果复选框被选中，高亮该行；否则，移除高亮
            $(this).toggleClass("highlight", checkbox.prop("checked"));

            // 自动调整全选复选框的状态
            adjustSelectAllCheckbox();
        }
    });

    // 全选/全不选的复选框
    $("#select-all").click(function () {
        var checked = $(this).prop("checked");
        $("input[type='checkbox']").prop("checked", checked);

        // 如果全选框被选中，高亮所有行；否则，移除所有行的高亮
        $("tr:gt(0)").toggleClass("highlight", checked);
    });

    // 检查并调整全选复选框的状态
    function adjustSelectAllCheckbox() {
        var allRows = $("input[type='checkbox']:not(#select-all)");
        var checkedRows = allRows.filter(":checked");
        $("#select-all").prop("checked", allRows.length === checkedRows.length);
    }
});

$(document).ready(function() {
    // 获取所有分组并填充 select
    function loadGroups() {
        $.ajax({
            url: "/groups",
            type: "GET",
            success: function(response) {
                let groupSelect = $("#group");
                let groupList = $("#groupList");
                groupSelect.empty();
                groupList.empty();
                Object.keys(response.data).forEach(function(groupName) {
                    groupSelect.append(`<option value="${groupName}">${groupName} (${response.data[groupName].records.length} 条记录)</option>`);
                    groupList.append(`
                        <li class="list-group-item">
                            <div class="input-group">
                                <input type="text" value="${groupName}" class="form-control group-name-input" readonly/>
                                <div class="input-group-append">
                                    <button class="btn btn-outline-secondary edit-group" data-group="${groupName}">编辑</button>
                                    <button class="btn btn-outline-success save-group" data-group="${groupName}" style="display: none;">保存</button>
                                    <button class="btn btn-outline-info show-group" data-group="${groupName}">展示</button>
                                    <button class="btn btn-outline-danger delete-group" data-group="${groupName}">删除</button>
                                </div>
                            </div>
                        </li>
                    `);
                });
            },
            error: function(error) {
                console.error("Error retrieving groups", error);
            }
        });
    }

    // 显示消息
    function showToast(message, messageType) {
        $('#toastBody').text(message);
        $('.toast').removeClass('toast-success toast-error');
        if (messageType === 'success') {
            $('.toast').addClass('toast-success');
        } else if (messageType === 'error') {
            $('.toast').addClass('toast-error');
        }
        $('.toast').toast({ delay: 3000 }).toast('show');
    }

    loadGroups(); // Call this function when the page loads

    // 创建分组
    $("#createGroup").click(function() {
        let newGroupName = $("#newGroupName").val();
        if (newGroupName === "") {
            showToast("分组名称不能为空");
            return;
        }
        $.ajax({
            url: "/groups",
            type:            "POST",
            data: JSON.stringify({Name: newGroupName, Records: []}),
            contentType: "application/json",
            success: function(response) {
                showToast("分组创建成功", "success");
                $("#newGroupName").val(""); // Clear the input field
                loadGroups(); // Refresh the groups list
            },
            error: function(jqXHR) {
                let errorMsg = jqXHR.responseJSON.error || "分组创建失败"; // 如果服务器返回了错误消息，就使用服务器的消息，否则使用默认的消息
                console.error("Error creating group", jqXHR);
                showToast(errorMsg, "error");
            }
        });
    });

    // 显示分组列表以便管理
    $("#groupManageModal").on('show.bs.modal', function (event) {
        loadGroups();
    });

    //分组展示
    $(document).on("click", ".show-group", function() {
        let groupName = $(this).data("group");
        let b64Group = btoa(unescape(encodeURIComponent(groupName)));
        window.location.href = `/admin/group/${b64Group}`;
    });
    
    // 绑定删除分组的点击事件
    $(document).on("click", ".delete-group", function() {
        let groupName = $(this).data("group");
        $.ajax({
            url: `/groups/${groupName}`,
            type: "DELETE",
            success: function(response) {
                showToast("分组删除成功", "success");
                loadGroups(); // Refresh the groups list
            },
            error: function(jqXHR) {
                let errorMsg = jqXHR.responseJSON.error || "分组删除失败"; // 如果服务器返回了错误消息，就使用服务器的消息，否则使用默认的消息
                console.error("Error deleting group", jqXHR);
                showToast(errorMsg, "error");
            }
        });
    });

    // 绑定编辑分组的点击事件
    $(document).on("click", ".edit-group", function() {
        let groupNameInput = $(this).closest('.input-group').find('.group-name-input');
        groupNameInput.prop('readonly', false); // Make the input field editable
        $(this).hide();
        $(this).siblings('.save-group').show();
    });

    // 绑定保存分组名的点击事件
    $(document).on("click", ".save-group", function() {
        let groupNameInput = $(this).closest('.input-group').find('.group-name-input');
        let oldGroupName = $(this).data('group');
        let newGroupName = groupNameInput.val();
        if (newGroupName === "") {
            showToast("分组名称不能为空", "error");
            return;
        }
        $.ajax({
            url: `/groups/${oldGroupName}`,
            type: "PUT",
            data: JSON.stringify({newName: newGroupName}),
            contentType: "application/json",
            success: function(response) {
                showToast("分组名修改成功", "success");
                loadGroups(); // Refresh the groups list
            },
            error: function(jqXHR) {
                let errorMsg = jqXHR.responseJSON.error || "分组名修改失败"; // 如果服务器返回了错误消息，就使用服务器的消息，否则使用默认的消息
                console.error("Error renaming group", jqXHR);
                showToast(errorMsg, "error");
            }
        });
    });
});



/*搜索处理*/
$('#search-button').click(function() {
    var keyword = $('#domain-search').val();
    window.location.href = '/search?keyword=' + encodeURIComponent(keyword);
});



document.addEventListener('DOMContentLoaded', function() {
    var exportBtn = document.getElementById('export-btn');
    if (exportBtn) {
        exportBtn.addEventListener('click', function() {
            window.open('/export');
        });
    }
});

document.getElementById('import-btn').addEventListener('click', function() {
    document.getElementById('import-file').click();
});

document.getElementById('import-file').addEventListener('change', function(e) {
    var file = e.target.files[0];
    if (file) {
        var reader = new FileReader();
        reader.onload = function(e) {
            var data = JSON.parse(e.target.result);
            $.ajax({
                url: '/import',
                method: 'POST',
                data: JSON.stringify(data),
                contentType: 'application/json',
                success: function(response) {
                    showModal('数据导入成功！');
                    location.reload();
                },
                error: function(response) {
                    showModal('数据导入失败，请检查文件格式是否正确！');
                }
            });
        };
        reader.readAsText(file);
    }
});


//点击批量移动分组按钮时
$('#bulk-move').click(function() {
    selectedDomains = [];
    $('.select-item:checked').each(function() {
        selectedDomains.push($(this).data('domain'));
    });

    if (selectedDomains.length === 0) {
        showModal('请至少选择一个域名进行操作');
        return;
    }

    // 获取所有分组并填充下拉选择框
    $.ajax({
        url: "/groups",
        type: "GET",
        success: function(response) {
            let newBulkGroupSelect = $("#newBulkGroup");
            newBulkGroupSelect.empty();
            Object.keys(response.data).forEach(function(groupName) {
                newBulkGroupSelect.append(`<option value="${groupName}">${groupName} (${response.data[groupName].records.length} records)</option>`);
            });
        },
        error: function(error) {
            console.error("Error retrieving groups", error);
        }
    });

    $('#bulkMoveModal').modal('show');
});

//点击移动分组按钮时
$('#confirmBulkMove').click(function() {
    let newGroup = $('#newBulkGroup').val();

    if(!newGroup){
        alert('请选择一个分组');
        return;
    }
    
    $('#bulkMoveModal').modal('hide');
    $('#loadingIndicator').show();

    fetch('/bulk_move', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({domains: selectedDomains, group: newGroup}),
    })
    .then((response) => {
        if (!response.ok) throw new Error(response.statusText);
        return response.text();
    })
    .then(() => {
        location.reload(true); // 强制从服务器加载页面
    })
    .catch((error) => {
        // handle any errors
        console.error('Error:', error);
        $('#loadingIndicator').hide();
        alert('操作失败，请稍后重试');
    });
});


$(document).on('click', '.status-btn', function() {
    const btn = $(this);
    const domain = btn.data('domain');

    // 发送请求到后端
    $.ajax({
        url: '/toggle_status',
        type: 'POST',
        data: { domain },
        success: function(response) {
            // 更新按钮的文本和背景颜色
            if (response.new_status == 'on') {
                btn.text('启用中');
                btn.css('background-color', 'green');
            } else {
                btn.text('停用中');
                btn.css('background-color', 'red');
            }
        },
        error: function(error) {
            // 处理错误
        }
    });
});


$(document).ready(function() {
    var domain;  // 定义一个全局的 domain 变量用于存储当前域名

    // 当点击上传证书按钮时
    $('.upload-certificate-btn').on('click', function() {
        domain = $(this).attr('data-domain');  // 从按钮的 data-domain 属性获取域名

        // 获取证书和私钥
        $.get(`/get_cert_and_key/${domain}`, function(data) {
            // 将获取到的证书和私钥显示在模态框中
            $('#certInput').val(data.certificate);
            $('#keyInput').val(data.private_key);
        });

        // 模态框删除按钮事件注册
        $('#modalDeleteCertBtn').off('click').on('click', function() {
            if (confirm('你确定要删除 ' + domain + ' 对应的证书吗？')) {
                $.ajax({
                    url: `/delete_cert_and_key/${domain}`,
                    type: 'DELETE',
                    success: function() {
                        // 删除成功后的操作，这里直接关闭了模态框并清空内容
                        $('#uploadCertModal').modal('hide');
                        $('#certInput').val('');
                        $('#keyInput').val('');
                        location.reload(true); // 强制刷新页面
                    },
                    error: function() {
                        // 删除失败后的操作
                        alert("删除失败！");
                    }
                });
            }
        });
    });
});
/**
 * 检查字符串是否包含非ASCII字符。
 *
 * @param {string} str - 待检测的字符串。
 * @return {boolean} 如果字符串包含非ASCII字符，则返回true，否则返回 false。
 */
 function containsNonAscii(str) {
    return /[^\x00-\x7F]/.test(str);
}

$(document).ready(function() {
    $('#saveCertBtn').on('click', function() {
        let domain = $('.upload-certificate-btn').data('domain');
        let cert = $('#certInput').val();
        let key = $('#keyInput').val();

        if (containsNonAscii(cert) || containsNonAscii(key)) {
            alert('存在非法字符，请删除所有非ASCII字符！');
            return;
        }

        cert = btoa(cert);
        key = btoa(key);

        // 向后台发送请求
        $.ajax({
            url: '/upload_cert',
            type: 'POST',
            data: {
                domain: domain,
                certificate: cert,
                private_key: key  
            },
            success: function(data, textStatus) {
                // 如果操作成功，弹出通知告诉用户
                alert('保存成功!');
            },
            error: function(xhr, textStatus, error) {
                // 如果操作失败，弹出错误消息
                alert(`保存失败: ${xhr.responseText}`);
            }
        });

        $('#uploadCertModal').modal('hide'); // 隐藏模态框
    });
});

// var page = 0;
// var pageSize = 10;  // 可以根据实际需要适当调整

// $(document).ready(function() {
//     $("#table-container").on('click', '.edit-btn', function() {
//         var domain = $(this).data('domain');
//         console.log("Clicked edit button for domain: " + domain);
//         // 在这里执行你的编辑功能
//     });

//     $("#table-container").on('click', '.https-btn', function() {
//         var domain = $(this).data('domain');
//         console.log("Clicked HTTPS button for domain: " + domain);
//         // 在这里执行你的 HTTPS 开启或关闭功能
//     });

//     $("#table-container").on('click', '.delete-btn', function() {
//         var domain = $(this).data('domain');
//         console.log("Clicked delete button for domain: " + domain);
//         // 在这里执行你的删除功能
//     });

//     loadMoreData();

//     $(window).scroll(function() {
//         if ($(window).scrollTop() + $(window).height() >= $(document).height() - 100) {
//             loadMoreData();
//         }
//     });
// });

// function loadMoreData() {
//     page++;  // 页面值递增

//     $.ajax({
//         url: "/admin/data?page=" + page + "&pageSize=" + pageSize,
//         method: "GET",
//         success: function(records) {
//             records.forEach(function(record) {
//                 var tr = $("<tr></tr>");
//                 var buttonText = record.status === "on" ? "启用中" : "停用中";
//                 var buttonColor = record.status === "on" ? "green" : "red";
        
//                 tr.append($("<td></td>")
//                     .append($('<input type="checkbox" class="select-item">').attr('data-domain', record.domain)))
//                     .append($("<td></td>").text(record.domain))
//                     .append($("<td></td>").addClass('redirect-cell').text(record.redirect))
//                     .append($("<td></td>").addClass('group-cell').text(record.group))
//                     .append($("<td></td>").addClass('visits-cell').text(record.visits))
//                     .append($("<td></td>").addClass('status-cell')
//                         .append($('<button type="button" class="btn status-btn">').css("background-color", buttonColor).attr('data-domain', record.domain).text(buttonText)));
        
//                 // 根据HTTPS字段的状态来显示不同的按钮
//                 var httpsBtn = $("<button></button>")
//                     .addClass("btn https-btn")
//                     .attr("data-domain", record.domain)
//                     .attr("data-loading-text", "开启中...");
        
//                 switch(record.https) {
//                     case "off":
//                         httpsBtn.addClass("btn-success").text("开启 HTTPS");
//                         break;
//                     case "on":
//                         httpsBtn.addClass("btn-secondary").attr("disabled", true).text("已开启 HTTPS");
//                         break;
//                     case "processing":
//                         httpsBtn.addClass("btn-warning").attr("disabled", true).text("正在开启 HTTPS...");
//                         break;
//                     case "failed":
//                         httpsBtn.addClass("btn-danger").text("开启失败 重试");
//                         break;
//                 }
        
//                 tr.append($("<td></td>")
//                     .append($('<button type="button" class="btn btn-warning edit-btn">')
//                         .attr('data-domain', record.domain)
//                         .text("修改"))
//                     .append(httpsBtn)
//                     .append($('<button type="button" class="btn delete-btn">')
//                         .attr('data-domain', record.domain)
//                         .text("删除")));
        
//                 $('#table-container .table tbody').append(tr);
//             });

//             document.querySelectorAll('.edit-btn').forEach(btn => {
//                 btn.addEventListener('click', function(event) {
//                     const row = event.target.closest('tr');
//                     currentDomainCell = row.cells[1];  
//                     currentRedirectCell = row.cells[2]; 
//                     currentGroupCell = row.cells[3]; 

//                     const originalDomain = currentDomainCell.textContent;
//                     const originalRedirect = currentRedirectCell.textContent;
//                     const originalGroup = currentGroupCell.textContent;

//                     const editModal = document.getElementById('editModal');

//                     document.getElementById('newDomain').value = originalDomain;
//                     document.getElementById('newRedirect').value = originalRedirect; 

//                     // Get groups from backend and fill in the group dropdown
//                     $.ajax({
//                         url: "/groups",
//                         type: "GET",
//                         success: function(response) {
//                             const newGroupSelect = $("#newGroup");
//                             newGroupSelect.empty();
//                             Object.keys(response.data).forEach(function(groupName) {
//                                 const selectedAttr = (groupName === originalGroup) ? "selected" : "";
//                                 newGroupSelect.append(`<option value="${groupName}" ${selectedAttr}>${groupName} (${response.data[groupName].records.length} records)</option>`);
//                             });
//                         },
//                         error: function(error) {
//                             console.error("Error retrieving groups", error);
//                         }
//                     });

//                     const myModal = new bootstrap.Modal(editModal);
//                     myModal.show();
//                 });
//             });



//         },
//         error: function(err) {
//             console.error('Fail to load more data:', err);
//         }
//     });
// }

// function attachDeleteButtonEventListeners() {
//     if (!document.__deleteButtonEventListenerAttached) {
//         document.addEventListener('click', function (event) {
//             if (event.target.classList.contains('delete-btn')) {
//                 event.preventDefault();
//                 event.stopPropagation();

//                 const domain = event.target.getAttribute('data-domain');
//                 const deleteModal = new bootstrap.Modal(document.getElementById('deleteConfirmModal'));

//                 // 将域名保存到模态框
//                 document.getElementById('deleteConfirmModal').dataset.domain = domain;

//                 deleteModal.show();
//             }
//         }, true);
//         document.__deleteButtonEventListenerAttached = true;
//     }
// }

// function handleHttpsButtonClick(){
//     var httpsButtons = document.getElementsByClassName('https-btn');
//     for (var i = 0; i < httpsButtons.length; i++) {
//         httpsButtons[i].addEventListener('click', function() {
//             var domain = this.getAttribute('data-domain');
//             var loadingText = this.getAttribute('data-loading-text');

//             this.innerHTML = '<i class="fa fa-spinner fa-spin"></i> ' + loadingText; // Use a loading spinner
//             this.disabled = true; // Disable the button

//             fetch('/enable_https/' + domain, {
//                 method: 'POST'
//             })
//             .then(response => response.json())
//             .then(data => {
//                 // Regardless of the result, keep the button as "正在开启..."
//             })
//             .catch((error) => {
//                 // Regardless of the result, keep the button as "正在开启..."
//             });
//         });
//     }
// }

// // 在全局范围内定义一个变量来存储当前的页码
// var currentPage = 1;

// window.onload = function() {
//     // 初始化页面
//     loadPageData(currentPage);

//     // 每页显示数量改变时重新加载数据
//     document.getElementById('rows-per-page').addEventListener('change', function() {
//         loadPageData(currentPage);
//     });

//     // 添加事件监听器到分页导航
//     document.getElementById('pagination').addEventListener('click', function(e) {
//         if (e.target.tagName.toLowerCase() === 'a') {
//             e.preventDefault();
//             currentPage = parseInt(e.target.dataset.page, 10); // 添加第二个参数10，表示十进制
//             loadPageData(currentPage);
//         }
//     });
//     // 添加事件监听器到删除按钮（初始加载的按钮）
//     attachDeleteButtonEventListeners();
// }


// // Function to attach event listeners to buttons
// function attachButtonEventListeners() {
//     // HTTPS按钮事件监听器
//     var httpsButtons = document.getElementsByClassName('https-btn');
//     for (var i = 0; i < httpsButtons.length; i++) {
//         // 移除旧的事件监听器
//         httpsButtons[i].removeEventListener('click', handleHttpsButtonClick);

//         // 添加新的事件监听器
//         httpsButtons[i].addEventListener('click', handleHttpsButtonClick);
//     }

//     // 删除按钮事件监听器
//     var deleteButtons = document.getElementsByClassName('delete-btn');
//     for (var i = 0; i < deleteButtons.length; i++) {
//         deleteButtons[i].addEventListener('click', function() {
//             deleteRecord(this);
//         });
//     }

//     // 添加这行代码来重新附加编辑按钮事件监听器
//     attachEditButtonEventListeners();
// }

// function attachEditButtonEventListeners() {
//     let currentDomainCell;
//     let currentRedirectCell;
//     let currentGroupCell;

//     document.querySelectorAll('.edit-btn').forEach(btn => {
//         btn.addEventListener('click', (event) => {
//             const row = event.target.closest('tr');
//             currentDomainCell = row.cells[1];
//             currentRedirectCell = row.cells[2];
//             currentGroupCell = row.cells[3];

//             const originalDomain = currentDomainCell.textContent;
//             const originalRedirect = currentRedirectCell.textContent;
//             const originalGroup = currentGroupCell.textContent;

//             const editModal = document.getElementById('editModal');

//             document.getElementById('newDomain').value = originalDomain;
//             document.getElementById('newRedirect').value = originalRedirect;
            
//             $.ajax({
//                 url: "/groups",
//                 type: "GET",
//                 success: function(response) {
//                     let newGroupSelect = $("#newGroup");
//                     newGroupSelect.empty();
//                     Object.keys(response.data).forEach(function(groupName) {
//                         let selectedAttr = (groupName === originalGroup) ? "selected" : "";
//                         newGroupSelect.append(`<option value="${groupName}" ${selectedAttr}>${groupName} (${response.data[groupName].records.length} records)</option>`);
//                     });
//                 },
//                 error: function(error) {
//                     console.error("Error retrieving groups", error);
//                 }
//             });

//             new bootstrap.Modal(editModal).show();
//         });
//     });

//     document.querySelector("#confirmEditBtn").addEventListener("click", function() {
//         let newDomain = document.querySelector("#newDomain").value;
//         let newRedirect = document.querySelector("#newRedirect").value;
//         let newGroup = document.querySelector("#newGroup").value;
//         let errorMsg = document.querySelector("#editError");

//         errorMsg.textContent = ''; 

//         if (!isValidDomain(newDomain)) {
//             errorMsg.textContent = "域名格式错误";
//             return false;
//         }

//         fetch('/update/' + currentDomainCell.textContent, {
//             method: 'POST',
//             headers: {
//                 'Content-Type': 'application/json'
//             },
//             body: JSON.stringify({
//                 'old_domain': currentDomainCell.textContent,
//                 'new_domain': newDomain,
//                 'new_redirect': newRedirect,
//                 'new_group': newGroup
//             })
//         })
//         .then(response => {
//             if (!response.ok) {
//                 return response.json().then(err => {throw err;});
//             }
//             return response.json();
//         })
//         .then(data => {
//             if (data.status == 'ok') {
//                 currentDomainCell.textContent = newDomain;
//                 currentRedirectCell.textContent = newRedirect;
//                 currentGroupCell.textContent = newGroup;
//                 $('#editModal').modal('hide');
//             } 
//         })
//         .catch(err => {
//             errorMsg.textContent = err.error;
//         });
//     });
// }

// function loadPageData(page) {
//     // 显示加载动画
//     document.getElementById('loading').style.display = 'block';

//     // 隐藏错误消息
//     document.getElementById('error-message').style.display = 'none';

//     // 获取每页显示数量
//     var perPage = document.getElementById('rows-per-page').value;

//     // 发送Ajax请求
//     var xhr = new XMLHttpRequest();
//     xhr.open('GET', '/loadPage?page=' + page + '&perPage=' + perPage, true);
//     xhr.onload = function() {
//         if (this.status === 200) {
//             // 隐藏加载动画
//             document.getElementById('loading').style.display = 'none';

//             // 解析返回的数据
//             var data = JSON.parse(this.responseText);

//             // 更新页面内容
//             updatePageContent(data);

//             // 更新分页导航
//             updatePagination(data, perPage); // 将 perPage 传递给 updatePagination 函数

//             // 重新附加按钮事件监听器
//             attachButtonEventListeners();


//         } else {
//             // 显示错误消息
//             document.getElementById('error-message').innerText = '加载数据失败，请刷新页面重试。';
//             document.getElementById('error-message').style.display = 'block';
//         }
//     };
//     xhr.send();
// }


// function updatePageContent(data) {
//     // 获取表格的tbody元素
//     var tbody = document.querySelector('.table tbody');

//     // 清空旧的表格行
//     while (tbody.firstChild) {
//         tbody.removeChild(tbody.firstChild);
//     }

//     // 添加新的表格行
//     data.records.forEach(function(record) {
//         var row = document.createElement('tr');

//         // 添加复选框
//         var checkboxCell = document.createElement('td');
//         var checkbox = document.createElement('input');
//         checkbox.type = 'checkbox';
//         checkbox.className = 'select-item';
//         checkbox.dataset.domain = record.domain;
//         checkboxCell.appendChild(checkbox);
//         row.appendChild(checkboxCell);

//         // 添加域名
//         var domainCell = document.createElement('td');
//         domainCell.innerText = record.domain;
//         row.appendChild(domainCell);

//         // 添加跳转地址
//         var redirectCell = document.createElement('td');
//         redirectCell.className = 'redirect-cell';
//         redirectCell.innerText = record.redirect;
//         row.appendChild(redirectCell);

//         // 添加所属分组
//         var groupCell = document.createElement('td');
//         groupCell.className = 'group-cell';
//         groupCell.innerText = record.group;
//         row.appendChild(groupCell);

//         // 添加访问次数
//         var visitsCell = document.createElement('td');
//         visitsCell.className = 'visits-cell';
//         visitsCell.innerText = record.visits;
//         row.appendChild(visitsCell);

//         // 添加域名状态
//         var statusCell = document.createElement('td');
//         statusCell.className = 'status-cell';
//         var statusBtn = document.createElement('button');
//         statusBtn.type = 'button';
//         statusBtn.className = 'btn status-btn';
//         statusBtn.dataset.domain = record.domain;
//         statusBtn.style.backgroundColor = record.status === 'on' ? 'green' : 'red';
//         statusBtn.innerText = record.status === 'on' ? '启用中' : '停用中';
//         statusCell.appendChild(statusBtn);
//         row.appendChild(statusCell);

//         // 添加操作
//         var operationCell = document.createElement('td');
//         var editBtn = document.createElement('button');
//         editBtn.type = 'button';
//         editBtn.className = 'btn btn-warning edit-btn';
//         editBtn.dataset.domain = record.domain;
//         editBtn.innerText = '修改';
//         operationCell.appendChild(editBtn);
//         row.appendChild(operationCell);

//         // 在此处添加HTTPS按钮
//         var httpsBtn = document.createElement('button');
//         httpsBtn.type = 'button';
//         httpsBtn.className = 'btn https-btn';
//         httpsBtn.dataset.domain = record.domain;

//         switch (record.https) {
//             case 'off':
//                 httpsBtn.className += ' btn-success';
//                 httpsBtn.dataset.loadingText = '开启中...';
//                 httpsBtn.innerText = '开启 HTTPS';
//                 break;
//             case 'on':
//                 httpsBtn.className += ' btn-secondary';
//                 httpsBtn.disabled = true;
//                 httpsBtn.innerText = '已开启 HTTPS';
//                 break;
//             case 'processing':
//                 httpsBtn.className += ' btn-warning';
//                 httpsBtn.disabled = true;
//                 httpsBtn.innerText = '正在开启 HTTPS...';
//                 break;
//             case 'failed':
//                 httpsBtn.className += ' btn-danger';
//                 httpsBtn.dataset.loadingText = '开启中...';
//                 httpsBtn.innerText = '开启失败 重试';
//                 break;
//         }

//         operationCell.appendChild(httpsBtn);

//         // 添加删除按钮
//         var deleteBtn = document.createElement('button');
//         deleteBtn.type = 'button';
//         deleteBtn.className = 'btn delete-btn';
//         deleteBtn.dataset.domain = record.domain;
//         deleteBtn.innerText = '删除';
//         operationCell.appendChild(deleteBtn);

//         tbody.appendChild(row);
//     });
// }

// function updatePagination(data, perPage) {
//     // 计算总页数
//     var totalPages = Math.ceil(data.total_records / perPage); // 使用传递的 perPage 来计算总页数
//     // 获取分页导航元素
//     var pagination = document.getElementById('pagination');

//     // 清空旧的页码链接
//     while (pagination.firstChild) {
//         pagination.removeChild(pagination.firstChild);
//     }
//     // 添加上一页按钮
//     var prevLi = document.createElement('li');
//     prevLi.className = 'page-item';
//     var prevA = document.createElement('a');
//     prevA.className = 'page-link';
//     prevA.href = '#';
//     prevA.dataset.page = Math.max(1, data.page - 1); // 上一页的页码是当前页减1，但不应小于1
//     prevA.innerText = '上一页';
//     prevLi.appendChild(prevA);
//     pagination.appendChild(prevLi);


//     // 添加页码链接
//     for (var i = 1; i <= totalPages; i++) {
//         var li = document.createElement('li');
//         li.className = 'page-item';

//         var a = document.createElement('a');
//         a.className = 'page-link';
//         a.href = '#';
//         a.dataset.page = i;
//         a.innerText = i;

//         li.appendChild(a);
//         pagination.appendChild(li);
//     }

//     // 添加下一页按钮
//     var nextLi = document.createElement('li');
//     nextLi.className = 'page-item';
//     var nextA = document.createElement('a');
//     nextA.className = 'page-link';
//     nextA.href = '#';
//     nextA.dataset.page = Math.min(totalPages, data.page + 1); // 下一页的页码是当前页加1，但不应大于总页数
//     nextA.innerText = '下一页';
//     nextLi.appendChild(nextA);
//     pagination.appendChild(nextLi);



//     // 处理上一页和下一页按钮的状态
//     prevLi.className = data.page === 1 ? 'page-item disabled' : 'page-item';
//     nextLi.className = data.page === totalPages ? 'page-item disabled' : 'page-item';

//       // 更新当前页码显示
//     document.getElementById('currentPage').innerText = '当前页：' + data.page;
// }

// document.getElementById('pagination').addEventListener('click', function(e) {
//     if (e.target.tagName.toLowerCase() === 'a') {
//         e.preventDefault();
//         var page = parseInt(e.target.dataset.page, 10); // 添加第二个参数10，表示十进制
//         loadPageData(page);
//     }
// }, { once: true });
