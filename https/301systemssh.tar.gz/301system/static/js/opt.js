document.getElementById('bulk-delete-btn').addEventListener('click', function() {
    const selectedDomains = Array.from(document.querySelectorAll('.select-record:checked')).map(function(checkbox) {
        return checkbox.dataset.domain;
    });
    if (selectedDomains.length > 0) {
        // 显示确认删除的模态框
        $('#bulkDeleteConfirmModal').modal('show');
    } else {
        showError('请选择需要删除的记录');
    }
});

document.getElementById('confirmBulkDelete').addEventListener('click', function() {
    const selectedDomains = Array.from(document.querySelectorAll('.select-record:checked')).map(function(checkbox) {
        return checkbox.dataset.domain;
    });
    // 执行批量删除操作
    deleteRecords(selectedDomains);
});

function deleteRecords(domains) {
    fetch('/bulk_delete', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({domains: domains}),
    })
    .then(function(response) {
        if (!response.ok) {
            throw new Error('网络响应不OK');
        }
        return response.json();
    })
    .then(function(data) {
        if (data.success) {
            location.reload(); // 如果删除成功，则刷新页面
        } else {
            showError(data.message || '删除记录失败');
        }
    })
    .catch(function(error) {
        showError(error.message);
    });
}


document.getElementById('select-all').addEventListener('change', function(e) {
    const checked = e.target.checked;
    document.querySelectorAll('.select-record').forEach(function(checkbox) {
        checkbox.checked = checked;
    });
});